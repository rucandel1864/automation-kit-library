# Free AI Workflow Governance Mini Pack

This free sample previews the governance style used in the paid AI Operations Workflow Library Business License.

## Included

- AI workflow approval checklist.
- Mini risk register.
- Business-license link.

## Not Included

This is not the full Business License package. The paid version includes the complete workflow library, 30-day rollout plan, governance template, department tracker, manager training deck outline, executive approval memo, and internal business license terms.
