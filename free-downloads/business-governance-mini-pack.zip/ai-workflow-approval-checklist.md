# AI Workflow Approval Checklist

Use this before letting a team use AI on a repeatable workflow.

## Workflow Fit

- The workflow is repeated often.
- Inputs are text-heavy or documentation-heavy.
- A human can review the output before it matters.
- The task does not require AI to make a final regulated decision.

## Data Rules

- Users know what data is allowed.
- Users know what data is prohibited.
- Sensitive customer, employee, financial, legal, medical, or payroll data has a separate review rule.

## Review Rules

- AI may draft, summarize, classify, or suggest.
- A human must approve external messages and final decisions.
- The workflow has an escalation owner.

## Measurement

- The owner tracks runs completed.
- The owner tracks estimated hours saved.
- The owner tracks rework and risky outputs.
- The SOP is updated when the workflow changes.
