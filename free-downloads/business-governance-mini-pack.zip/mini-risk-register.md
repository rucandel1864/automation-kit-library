# Mini AI Workflow Risk Register

| Risk | Mitigation |
| --- | --- |
| Sensitive data is pasted into an AI tool | Define allowed and prohibited inputs before rollout. |
| AI invents facts | Require source checks and assumption labels. |
| Unreviewed customer-facing output is sent | Require human approval before external use. |
| Prompt becomes stale | Assign a workflow owner and review monthly. |
| Users ignore the SOP | Track adoption and pause workflows with repeated misses. |

## Use Rule

Start with low-risk internal drafting, summarizing, routing, or SOP documentation. Do not start with legal, medical, payroll, hiring, financial approval, or safety-critical decisions.
