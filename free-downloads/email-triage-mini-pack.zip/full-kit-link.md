# Full Kit

The full AI Email Triage Kit includes:

- setup guide,
- standard operating procedure,
- full triage prompt,
- reply polisher prompt,
- ROI worksheet,
- safety checklist,
- workflow diagram,
- team handoff template.

Product page:

https://rucandel1864.github.io/automation-kit-library/products/email-triage.html

Bundle page:

https://rucandel1864.github.io/automation-kit-library/products/starter-bundle.html
