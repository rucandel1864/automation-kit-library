# Safety Note

This mini prompt is designed for human-approved triage. Do not connect it to autonomous email sending.

Safe use:

- classify messages,
- summarize threads,
- suggest an owner,
- suggest next action,
- help a human decide what to do.

Unsafe use:

- auto-sending replies,
- making refund or policy decisions,
- handling sensitive data without approval,
- legal, medical, financial, or security advice.

For the full workflow, use the paid AI Email Triage Kit or the Operations Workflow Library Bundle.
