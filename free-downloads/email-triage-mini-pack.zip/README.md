# AI Email Triage Mini Pack

This free mini pack is a small sample from Automation Kit Library.

It includes:

- one email triage prompt,
- a short safety note,
- a link to the full AI Email Triage Kit and Operations Workflow Library Bundle.

It does not include the full paid kit's setup guide, SOP, ROI worksheet, workflow diagram, reply polisher prompt, or team handoff template.

## Full Kits

The full product library is available at:

https://rucandel1864.github.io/automation-kit-library/
