# Free AI Policy Mini Pack

This mini pack helps a small business draft internal AI usage rules before a workflow rollout.

Included:

- `starter-ai-usage-policy.md`: a practical policy draft.
- `policy-review-checklist.md`: review questions for owners and managers.
- `business-license-link.md`: where to find the full rollout package.

This is a public sample, not legal, security, or compliance advice. Have the responsible business, security, and compliance owners review the policy before use.
