# Full Business License

The full AI Operations Workflow Library Business License includes:

- All four workflow kits.
- Business rollout plan.
- Governance template.
- Department rollout tracker.
- Risk register.
- Executive approval memo materials.
- Internal use rights for up to 50 users in one organization.

Business License page:

https://rucandel1864.github.io/automation-kit-library/products/business-license.html

Free policy builder:

https://rucandel1864.github.io/automation-kit-library/tools/ai-policy-builder.html
