# Starter AI Usage Policy

## Purpose

This policy defines safe, useful, human-reviewed AI use for internal business workflows.

## Allowed Use Cases

- Draft internal SOPs from process-owner notes.
- Summarize meeting notes into decisions, owners, and next actions.
- Classify non-sensitive inbox messages for human review.
- Draft lead follow-up messages that a human approves before sending.

## Prohibited Inputs

- Passwords, API keys, tokens, or private credentials.
- Customer payment details.
- Medical, legal, financial, or regulated personal information.
- Confidential contracts, unreleased financials, or sensitive employee records.

## Human Approval Gates

AI output must be reviewed by a qualified person before:

- Sending external messages.
- Changing customer records.
- Publishing documents.
- Making commitments on behalf of the company.

## Ownership

- Policy owner: assign one accountable owner.
- Workflow owner: assign one owner for each AI-assisted workflow.
- Escalation owner: assign one person to review unclear, sensitive, or high-impact use cases.

## Review Cadence

Review monthly for the first quarter of rollout, then quarterly or after any major workflow change.
