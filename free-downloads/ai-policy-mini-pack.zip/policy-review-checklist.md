# AI Policy Review Checklist

Use this checklist before sharing an AI usage policy with the team.

## Scope

- [ ] The policy names the team or department it applies to.
- [ ] The allowed workflows are specific enough for operators to follow.
- [ ] High-risk workflows are excluded or require owner approval.

## Data Rules

- [ ] Prohibited inputs are written in plain language.
- [ ] The policy says not to paste credentials, payment data, regulated personal data, or confidential contracts.
- [ ] Operators know who to ask when they are unsure whether an input is allowed.

## Approval Gates

- [ ] External messages require human review.
- [ ] Customer-record changes require human review.
- [ ] Published documents require human review.
- [ ] Business commitments require human review.

## Ownership

- [ ] The policy owner is named.
- [ ] Each workflow has a workflow owner.
- [ ] Escalation rules are clear.
- [ ] The first review date is scheduled.
